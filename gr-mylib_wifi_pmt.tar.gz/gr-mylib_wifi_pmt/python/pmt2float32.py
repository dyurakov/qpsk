#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Copyright 2022 dmitr.
#
# SPDX-License-Identifier: GPL-3.0-or-later
#


import pmt 
import numpy as np
from gnuradio import gr
textboxValue = ""
text = 0

class pmt2float32(gr.sync_block):
    """
    docstring for block pmt2float32
    """
    def __init__(self):
        gr.sync_block.__init__(self,
            name="pmt2float32",
            in_sig = None,
            out_sig=[np.float32])
        self.message_port_register_in(pmt.intern('In'))
        self.set_msg_handler(pmt.intern('In'), self.handle_msg)

    def handle_msg(self, msg):
        global text
        textboxValue = msg
        text = pmt.to_double(textboxValue)



    def work(self, input_items, output_items):
        global text
        output_items[0][:] = text
        return len(output_items[0])
