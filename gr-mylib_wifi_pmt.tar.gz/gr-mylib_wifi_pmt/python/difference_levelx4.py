#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Copyright 2022 dmitr.
#
# SPDX-License-Identifier: GPL-3.0-or-later
#



import numpy as np
import pmt 
from gnuradio import gr

dl =1024*4

chkl = 0
chkr = 0
povtor =10
sch2 =0

rez = 0.0
pzu1 = [0]*dl
pzu2 = 0
sch=0
sr=0.0

LL = 0.0
L = 0.0
R = 0.0
RR = 0.0
tL = 0
tR = 0

class difference_levelx4(gr.sync_block):
    """
    docstring for block difference_levelx4
    """
    def __init__(self):
        gr.sync_block.__init__(self,
            name="difference_levelx4",
            in_sig=None,
            out_sig=None)


        self.message_port_register_in(pmt.intern('In_LL'))
        self.set_msg_handler(pmt.intern('In_LL'), self.handle_msgLL)
        
        self.message_port_register_in(pmt.intern('In_L'))
        self.set_msg_handler(pmt.intern('In_L'), self.handle_msgL)
        
        self.message_port_register_in(pmt.intern('In_R'))
        self.set_msg_handler(pmt.intern('In_R'), self.handle_msgR)
        
        self.message_port_register_in(pmt.intern('In_RR'))
        self.set_msg_handler(pmt.intern('In_RR'), self.handle_msgRR)
        

    # Levo levo
    def handle_msgLL(self, msg):
        global LL
        LL = pmt.to_double(msg)
        #print(LL)
    # levo    
    def handle_msgL(self, msg):
        global L
        L = pmt.to_double(msg)
    # pravo
    def handle_msgR(self, msg):
        global R
        R = pmt.to_double(msg)
        #print(R)
    # Pravo pravo
    def handle_msgRR(self, msg):
        global LL, L, R, RR, pzu1,sch,sr, dl, chkl, chkr
        RR = pmt.to_double(msg)
        #print(RR)
        
        print('RR = ',RR,'R = ',R,'L = ',L, 'LL = ',LL)        
        
        
        if LL >= L > R > RR:
            print ('######### LEVO #########')        
        
        if RR >= R > L > LL:
            print ('######### PRAVO #########')
