#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Copyright 2022 dmitr.
#
# SPDX-License-Identifier: GPL-3.0-or-later
#
from gnuradio import gr
from gnuradio import blocks
from gnuradio import digital
import numpy as np

np.set_printoptions(threshold=np.sys.maxsize)

_tracep = False
def tprint(msg):
    if _tracep:
        print(msg)



class del_barking_code(gr.basic_block):
    """
    docstring for block del_barking_code
    """
    def __init__(self):
        gr.basic_block.__init__(self,
            name="del_barking_code",
            in_sig=[np.uint8],
            out_sig=[np.uint8])

        ##################################################
        # Put Variables Here
        ##################################################
        self.syncSize = 32
        self.packetSize = 1024
        self.tolerance = 0
        self.syncAndPacketSize = self.syncSize + self.packetSize
        self.barkersequence = np.array([-1, -1, -1, -1, -1, 1, 1, -1, -1, 1, -1, 1, -1, -1, -1, -1]*2)

    def general_work(self, input_items, output_items):

        # Initial housekeeping
        in0 = input_items[0]
        out = output_items[0]

        # Во-первых, убедитесь, что буфер имеет достаточно битов для обработки
        if len(in0) < self.syncAndPacketSize:
            self.consume_each(int(0))
            return 0
            
        # Cканирование для синхронизации
        correlationOutput = np.correlate(in0.astype(np.int32) * 2 - 1, self.barkersequence)
        maxCorrIndex = np.argmax(correlationOutput)
        maxCorrValue = correlationOutput[maxCorrIndex]

        # если совпадение неудачное, сбросьте буферы, чтобы повторить попытку
        if maxCorrValue < (self.syncSize - self.tolerance):
            tprint("Корреляция Баркера недостаточна, сброс буфера.")
            self.consume_each(int(len(in0)))
            return 0

        # Good match - do we have room?
        #  TODO: возможно, есть еще одно промежуточное состояние, которое позволяет нам избежать повторного сканирования для Баркера
        if len(in0) < (maxCorrIndex + self.syncAndPacketSize):
            tprint("Баркер найден, но нужны дополнительные данные - заполнение буфера.")
            self.consume_each(int(maxCorrIndex - 1))
            return 0
        index =0
        for i in in0[maxCorrIndex + self.syncSize : maxCorrIndex + self.syncAndPacketSize-1]:
            out[index] = i
            index +=1
        self.consume_each(int(maxCorrIndex + self.syncAndPacketSize))
        return (self.packetSize)
