#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Copyright 2022 dmitr.
#
# SPDX-License-Identifier: GPL-3.0-or-later
#


import numpy as np
import pmt 
from gnuradio import gr
dl =1024*4

chkl = 0
chkr = 0
povtor =10
sch2 =0

rez = 0.0
pzu1 = [0]*dl
pzu2 = 0
sch=0
sr=0.0

L = 0.0
R = 0.0
tL = 0
tR = 0


class difference_level(gr.sync_block):  # other base classes are basic_block, decim_block, interp_block
    """Embedded Python Block example - a simple multiply const"""

    def __init__(self):  # only default arguments here
        """arguments to this function show up as parameters in GRC"""
        gr.sync_block.__init__(
            self, name='DL in2',in_sig=None, out_sig=None)
        self.message_port_register_in(pmt.intern('In_L'))
        self.set_msg_handler(pmt.intern('In_L'), self.handle_msgL)
        
        self.message_port_register_in(pmt.intern('In_R'))
        self.set_msg_handler(pmt.intern('In_R'), self.handle_msgR)
        
        #self.message_port_register_in(pmt.intern('TimeL'))
        #self.set_msg_handler(pmt.intern('TimeL'), self.handle_timeL)  
        
        #self.message_port_register_in(pmt.intern('TimeR'))
        #self.set_msg_handler(pmt.intern('TimeR'), self.handle_timeR)    


#    def handle_timeL(self,msg):
#        global tL
#        tL = pmt.to_long(msg)
#        #tR = pmt.to_long(msg)
#    def handle_timeR(self,msg):
#        global tL
#        #tL = pmt.to_long(msg)
#        tR = pmt.to_long(msg)
#        print(tL-tR)
        
        
    def handle_msgL(self, msg):
        global L
        L = pmt.to_double(msg)
        #tL = pmt.to_long(msg)
        #return(0)

    def handle_msgR(self, msg):
        global R, L, pzu1,sch,sr, dl, chkl, chkr
        R = pmt.to_double(msg)
        
        
        
        #rez = R - L
        pzu1[sch] = R-L
        sch +=1
        
        
        
        if len(pzu1) ==dl:
            sr = sum(pzu1)/(len(pzu1)-1)
            #print(sr)
            sch = 0   
            if sr > 0:
                if chkr < povtor: 
                    chkr += 1
                    chkl = 0
                else:    
                    print('>>>>>>>>>>>>>ПРАВО>>>>>>>>>>>>>>>>>')
                    chkr = 0
            
            
            elif sr < 0:
                if chkl < povtor: 
                    chkl += 1
                    chkr = 0
                else:    
                    print('>>>>>>>>>>>>>ЛЕВО>>>>>>>>>>>>>>>>>')
                    chkl = 0
