This directory stores templates for docstrings that are scraped from the include header files for each block
