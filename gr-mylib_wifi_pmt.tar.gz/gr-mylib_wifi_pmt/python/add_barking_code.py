#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Copyright 2022 dmitr.
#
# SPDX-License-Identifier: GPL-3.0-or-later
#


import numpy as np
from gnuradio import gr

class add_barking_code(gr.basic_block):
    """
    docstring for block add_barking_code
    """
    def __init__(self):
        gr.basic_block.__init__(self,
            name="add_barking_code",
            in_sig=[np.uint8],
            out_sig=[np.uint8])

        self.barkersequence = [0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0]*2
        self.syncLength = len(self.barkersequence)
        self.PACKET_SIZE = 1024

    def general_work(self, input_items, output_items):
	#ПРИНИМАЕТ распакованные байты и добавляет коды баркера
        if len(input_items[0]) > self.PACKET_SIZE and len(output_items[0]) > self.PACKET_SIZE + self.syncLength:
            for i in range(len(self.barkersequence)):
                output_items[0][i] = self.barkersequence[i]
            for i in range(self.PACKET_SIZE):
                output_items[0][self.syncLength+i] = input_items[0][i]
            self.consume_each(self.PACKET_SIZE);
            return self.PACKET_SIZE + self.syncLength
        return 0

