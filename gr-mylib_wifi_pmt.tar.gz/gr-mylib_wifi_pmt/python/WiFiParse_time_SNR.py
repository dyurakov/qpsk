#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Copyright 2022 dmitr.
#
# SPDX-License-Identifier: GPL-3.0-or-later
#


import pmt 
import numpy as np
from gnuradio import gr


class WiFiParse_time_SNR(gr.sync_block):
    """
    docstring for block WiFiParse_time_SNR
    """
    def __init__(self, find_mac_tx = ''):
        gr.sync_block.__init__(self,
            name="WiFiParse_time_SNR",
            in_sig=None,
            out_sig=None)


        #Регистрация входного порта
        self.message_port_register_in(pmt.intern('In'))
        self.set_msg_handler(pmt.intern('In'), self.handle_msg)
        
        #Регистрация выходных портов
        self.message_port_register_out(pmt.intern('SNR'))
        self.message_port_register_out(pmt.intern('time'))
        #Переменные из блоков
        self.mac = find_mac_tx


        
    def handle_msg(self, msg):
        time =pmt.to_long( pmt.dict_ref(msg, pmt.intern("time"), pmt.PMT_NIL ))
        addr2 = pmt.symbol_to_string(pmt.dict_ref(msg, pmt.intern("addr2"), pmt.PMT_NIL )) # строка / МАС адрес устройства передающего.        
        snr = pmt.to_double(pmt.dict_ref(msg, pmt.intern("snr"), pmt.PMT_NIL )) # double  должно быть / snr  расчитанный программно
        sch = int(pmt.to_double(pmt.dict_ref(msg, pmt.intern("sch"), pmt.PMT_NIL )) )# double  должно быть /  количество символов непрерывной корреляции в заголовке пакета
        frequency_offset = pmt.to_double(pmt.dict_ref(msg, pmt.intern("frequency_offset"), pmt.PMT_NIL )) # double  должно быть / частота смещения относительно центральной
        
        
        #print(frequency_offset)
        if addr2 == self.mac:
            #print('My')
            self.message_port_pub(pmt.intern('SNR'), pmt.dict_ref(msg, pmt.intern("snr"), pmt.PMT_NIL ) )

            self.message_port_pub(pmt.intern('time'), pmt.dict_ref(msg, pmt.intern("time"), pmt.PMT_NIL ) )
            #pass
        #else:
            #print('No')


    def work(self, input_items, output_items):
        pass

