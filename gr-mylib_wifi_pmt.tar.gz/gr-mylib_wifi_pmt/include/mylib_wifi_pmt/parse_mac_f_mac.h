/* -*- c++ -*- */
/*
 * Copyright 2022 dmitr .
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

#ifndef INCLUDED_MYLIB_WIFI_PMT_PARSE_MAC_F_MAC_H
#define INCLUDED_MYLIB_WIFI_PMT_PARSE_MAC_F_MAC_H

#include <gnuradio/block.h>
#include <mylib_wifi_pmt/api.h>

namespace gr {
namespace mylib_wifi_pmt {

/*!
 * \brief <+description of block+>
 * \ingroup mylib_wifi_pmt
 *
 */
class MYLIB_WIFI_PMT_API parse_mac_f_mac : virtual public gr::block
{
public:
    typedef std::shared_ptr<parse_mac_f_mac> sptr;

    /*!
     * \brief Return a shared_ptr to a new instance of mylib_wifi_pmt::parse_mac_f_mac.
     *
     * To avoid accidental use of raw pointers, mylib_wifi_pmt::parse_mac_f_mac's
     * constructor is in a private implementation
     * class. mylib_wifi_pmt::parse_mac_f_mac::make is the public interface for
     * creating new instances.
     */
    static sptr make(std::string mac_addr2);
};

} // namespace mylib_wifi_pmt
} // namespace gr

#endif /* INCLUDED_MYLIB_WIFI_PMT_PARSE_MAC_F_MAC_H */
