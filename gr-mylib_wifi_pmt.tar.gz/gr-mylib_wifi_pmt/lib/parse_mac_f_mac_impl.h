/* -*- c++ -*- */
/*
 * Copyright 2022 dmitr.
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

#ifndef IINCLUDED_MYLIB_WIFI_PMT_PARSE_MAC_F_MAC_IMPL_H
#define IINCLUDED_MYLIB_WIFI_PMT_PARSE_MAC_F_MAC_IMPL_H

#include <mylib_wifi_pmt/parse_mac_f_mac.h>

namespace gr 
{
  namespace mylib_wifi_pmt 
  {

    class parse_mac_f_mac_impl : public parse_mac_f_mac
      { // start class
      private:
      bool d_debug;
      char fmac_addr2[6];
      void parse(pmt::pmt_t pdu);

      public:
      parse_mac_f_mac_impl(std::string mac_addr2);
      ~parse_mac_f_mac_impl();  
      }; // end class

  } // namespace test3
} // namespace gr

#endif /* INCLUDED_TEST3_PARSE_MAC_F_MAC_IMPL_H */
