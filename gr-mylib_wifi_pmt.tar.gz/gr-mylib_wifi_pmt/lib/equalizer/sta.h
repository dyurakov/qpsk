

#ifndef INCLUDED_MYLIB_WIFI_PMT_EQUALIZER_STA_H
#define INCLUDED_MYLIB_WIFI_PMT_EQUALIZER_STA_H

#include "base.h"
#include <vector>

namespace gr {
namespace mylib_wifi_pmt {
namespace equalizer {

class sta : public base
{
public:
    virtual void equalize(gr_complex* in,
                          int n,
                          gr_complex* symbols,
                          uint8_t* bits,
                          std::shared_ptr<gr::digital::constellation> mod);
    double get_snr();

private:
    double d_snr;

    const double alpha = 0.5;
    const int beta = 2;
};

} // namespace equalizer
} /* namespace mylib_wifi_pmt */
} /* namespace gr */

#endif 
