

#ifndef INCLUDED_MYLIB_WIFI_PMT_EQUALIZER_COMB_H
#define INCLUDED_MYLIB_WIFI_PMT_EQUALIZER_COMB_H

#include "base.h"

namespace gr {
namespace mylib_wifi_pmt {
namespace equalizer {

class comb : public base
{
public:
    virtual void equalize(gr_complex* in,
                          int n,
                          gr_complex* symbols,
                          uint8_t* bits,
                          std::shared_ptr<gr::digital::constellation> mod);
    double get_snr();

private:
    const double alpha = 0.2;
};

} // namespace equalizer
} /* namespace mylib_wifi_pmt */
} /* namespace gr */

#endif /* mylib_wifi_pmt */
