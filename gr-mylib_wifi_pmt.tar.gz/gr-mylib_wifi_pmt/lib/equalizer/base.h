

#ifndef INCLUDED_MYLIB_WIFI_PMT_EQUALIZER_BASE_H
#define INCLUDED_MYLIB_WIFI_PMT_EQUALIZER_BASE_H

#include <gnuradio/digital/constellation.h>
#include <gnuradio/gr_complex.h>

namespace gr {
namespace mylib_wifi_pmt {
namespace equalizer {

class base
{
public:
    virtual ~base(){};
    virtual void equalize(gr_complex* in,
                          int n,
                          gr_complex* symbols,
                          uint8_t* bits,
                          std::shared_ptr<gr::digital::constellation> mod) = 0;
    virtual double get_snr() = 0;

    static const gr_complex POLARITY[127];

    std::vector<gr_complex> get_csi();

protected:
    static const gr_complex LONG[64];

    gr_complex d_H[64];
};

} // namespace equalizer
} /* namespace mylib_wifi_pmt */
} /* namespace gr */

#endif /* mylib_wifi_pmt */
