/* -*- c++ -*- */
/*
 * Copyright 2022 dmitr.
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */


#include "utils.h"
#include "parse_mac_f_mac_impl.h"
#include <gnuradio/io_signature.h>
#include <gnuradio/block_detail.h>




#include <volk/volk.h>

//Мои инклуды
#include <string>
#include <iostream>
#include <fstream>
#include <ctime>
#include <chrono>

namespace gr 
{
    namespace mylib_wifi_pmt 
    {


        parse_mac_f_mac::sptr parse_mac_f_mac::make(std::string mac_addr2)
        {
            return gnuradio::make_block_sptr<parse_mac_f_mac_impl>(mac_addr2);
        }


        /*
         * The private constructor
         */
        parse_mac_f_mac_impl::parse_mac_f_mac_impl(std::string mac_addr2)
            : gr::block("parse_mac_f_mac",
                    gr::io_signature::make(
                    0, 0, 0),
                gr::io_signature::make(
                    0, 0, 0)),
                    d_debug(false)
        {
    
               if(std::sscanf(mac_addr2.c_str(), "%hhx:%hhx:%hhx:%hhx:%hhx:%hhx",
    		&fmac_addr2[0], &fmac_addr2[1], &fmac_addr2[2], &fmac_addr2[3], &fmac_addr2[4], &fmac_addr2[5]) != 6)
    		throw std::invalid_argument("wrong mac address size");
    
            message_port_register_in(pmt::mp("in"));
            set_msg_handler(
                pmt::mp("in"),
                boost::bind(&parse_mac_f_mac_impl::parse, this, boost::placeholders::_1));

            message_port_register_out(pmt::mp("snr"));
            message_port_register_out(pmt::mp("out"));
        }

        /*
         * Our virtual destructor.
         */
        parse_mac_f_mac_impl::~parse_mac_f_mac_impl() {}

        std::string format_mac_address(uint8_t* addr)
            { //start format_mac_address
                
                std::stringstream str;
                str << std::setfill('0') << std::hex << std::setw(2) << (int)addr[0];
                for (int i = 1; i < 6; i++) { // start for
                str << ":" << std::setw(2) << (int)addr[i];
                } // end for

                return str.str();
            } // end format_mac_address




        void parse_mac_f_mac_impl::parse(pmt::pmt_t pdu)
	        { // start parse_mac_f_mac_impl

    		    if (pmt::is_eof_object(pdu)) 
                { //start if
    			    detail().get()->set_done(true);
    			    return;
		        }  // end if
                else if (pmt::is_symbol(pdu)) 
                { //start else
			        return;
		        } //end else


        		pmt::pmt_t meta = pmt::car(pdu);
        		pmt::pmt_t msg = pmt::cdr(pdu);
        
                int frame_len = pmt::blob_length(msg);
                mac_header* h = (mac_header*)pmt::blob_data(msg);
        
                // Получение длинны STF
                auto d_itog = pmt::dict_ref(meta, pmt::mp("sch") , pmt::mp("sch"));
                // Плучение значения SNR
                auto SNR = pmt::dict_ref(meta, pmt::mp("snr") , pmt::mp("snr"));
                // Получение смещение частоты из тегов  
                auto frequency_offset = pmt::dict_ref(meta, pmt::mp("frequency offset") , pmt::mp("frequency offset"));

        
                // Получение адресов
                auto address1 = format_mac_address(h->addr1);
                auto address2 = format_mac_address(h->addr2);
                auto address3 = format_mac_address(h->addr3);

        
        
                if(memcmp(h->addr2, fmac_addr2, 6) == 0) // Сравнивает но не как строку а как содержимое           
                    { // start if
            
                    //Печать в файл
                    //std::string txt = mac_address(fmac_addr2);
                    //std::string txt = mac_address(fmac_addr2);
                    //std::string txt1 = mac_addr2.str();

                    //std::string txt1[17] = {txt[6],txt[7],txt[8],txt[9],txt[10],txt[11],txt[18],txt[19],txt[20],txt[21],txt[22],txt[23],txt[30],txt[31],txt[32],txt[33],txt[34] };
                    //auto txt = (int)fmac_addr2[0];

                    /*
                    std::ofstream ofile;
                    ofile.open("addr.txt", std::ios::app); 
                    //ofile <<  txt[6] << txt[7] << txt[8] << txt[9] << txt[10] << txt[11] << std::endl;
                    ofile <<  txt1 << std::endl;
                    ofile.close();   
                    */

                    // Узнаём время в наносекундах относительно пк
                    std::chrono::time_point<std::chrono::system_clock> now = std::chrono::system_clock::now();
                    auto duration = now.time_since_epoch();
                    auto nanoseconds = std::chrono::duration_cast<std::chrono::nanoseconds>(duration);

                    // Создание словаря
                    pmt::pmt_t slovar = pmt::make_dict();
                    // Собираем словарь созначениями: время, частота смещения, счётчик STF, SNR, MAC адреса 
                    slovar = pmt::dict_add(slovar, pmt::mp("time"),               pmt::mp(static_cast<int64_t>(nanoseconds.count())) );
                    slovar = pmt::dict_add(slovar, pmt::mp("frequency_offset"),   frequency_offset);
                    slovar = pmt::dict_add(slovar, pmt::mp("sch"),                d_itog);         
                    slovar = pmt::dict_add(slovar, pmt::mp("snr"),                SNR);
                    slovar = pmt::dict_add(slovar, pmt::mp("addr3"),              pmt::mp(address3) );
                    slovar = pmt::dict_add(slovar, pmt::mp("addr2"),              pmt::mp(address2) );
                    slovar = pmt::dict_add(slovar, pmt::mp("addr1"),              pmt::mp(address1) );
            


            
                    message_port_pub(pmt::mp("out"),  slovar);    
                    message_port_pub(pmt::mp("snr"),  SNR);
                    } // end if


            } //end void


    } /* namespace mylib_wifi_pmt */
} /* namespace gr */
